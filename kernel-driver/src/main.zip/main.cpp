﻿#include <ntddk.h>
#include <ntstrsafe.h>
#include <stdlib.h>
#include <wdf.h>

_Dispatch_type_(IRP_MJ_DEVICE_CONTROL)
extern "C" DRIVER_DISPATCH DispatchDeviceControl;

void DebugPrint(PCSTR text) {
#ifndef DEBUG
	UNREFERENCED_PARAMETER(text);
#endif // DEBUG

	KdPrintEx((DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL, text));
}

namespace codes {
	constexpr ULONG IOCTL_LIST_PROCESSES = CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_READ_DATA);
}

NTSTATUS DispatchCreateClose(PDEVICE_OBJECT deviceObject, PIRP Irp) {
	UNREFERENCED_PARAMETER(deviceObject);
	Irp->IoStatus.Status = STATUS_SUCCESS;
	Irp->IoStatus.Information = 0;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return STATUS_SUCCESS;
}

typedef struct _SYSTEM_THREADS {
	LARGE_INTEGER  KernelTime;
	LARGE_INTEGER  UserTime;
	LARGE_INTEGER  CreateTime;
	ULONG          WaitTime;
	PVOID          StartAddress;
	CLIENT_ID      ClientId;
	KPRIORITY      Priority;
	KPRIORITY      BasePriority;
	ULONG          ContextSwitchCount;
	LONG           State;
	LONG           WaitReason;
} SYSTEM_THREADS, * PSYSTEM_THREADS;

typedef struct _SYSTEM_PROCESSES {
	ULONG            NextEntryDelta;
	ULONG            ThreadCount;
	ULONG            Reserved1[6];
	LARGE_INTEGER    CreateTime;
	LARGE_INTEGER    UserTime;
	LARGE_INTEGER    KernelTime;
	UNICODE_STRING   ProcessName;
	KPRIORITY        BasePriority;
	SIZE_T           ProcessId;
	SIZE_T           InheritedFromProcessId;
	ULONG            HandleCount;
	ULONG            Reserved2[2];
	VM_COUNTERS      VmCounters;
	IO_COUNTERS      IoCounters;
	SYSTEM_THREADS   Threads[1];
} SYSTEM_PROCESSES, * PSYSTEM_PROCESSES;

#define SystemProcessInformation 5

#define POOL_TAG 'enoN'

extern "C"
NTSTATUS NTAPI ZwQuerySystemInformation(ULONG SystemInformationClass, PVOID SystemInformation, ULONG SystemInformationLength, PULONG ReturnLength);

NTSTATUS ListProcesses() {
	NTSTATUS ntstatus = STATUS_SUCCESS;

	UNICODE_STRING uniName = RTL_CONSTANT_STRING(L"\\SystemRoot\\KernelProcessList.txt");
	OBJECT_ATTRIBUTES objAttr;

	InitializeObjectAttributes(&objAttr, &uniName,
		OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE,
		NULL, NULL);

	HANDLE file;
	IO_STATUS_BLOCK ioStatusBlock;

	ntstatus = ZwCreateFile(&file,
		GENERIC_WRITE,
		&objAttr, &ioStatusBlock, NULL,
		FILE_ATTRIBUTE_NORMAL,
		0,
		FILE_OVERWRITE_IF,
		FILE_SYNCHRONOUS_IO_NONALERT,
		NULL, 0);

	if (NT_SUCCESS(ntstatus)) {
		ULONG bufferSize = 0;

		if (ZwQuerySystemInformation(SystemProcessInformation, NULL, 0, &bufferSize) == STATUS_INFO_LENGTH_MISMATCH) {
			if (bufferSize) {
				PVOID memory = ExAllocatePoolWithTag(PagedPool, bufferSize, POOL_TAG);

				if (memory) {
					ntstatus = ZwQuerySystemInformation(SystemProcessInformation, memory, bufferSize, &bufferSize);
					if (NT_SUCCESS(ntstatus)) {
						PSYSTEM_PROCESSES processEntry = (PSYSTEM_PROCESSES)memory;

						do {
							if (processEntry->ProcessName.Length) {
								CHAR string[100];
								ntstatus = RtlStringCbPrintfA(string, _countof(string), "%ws : %llu\n", processEntry->ProcessName.Buffer, processEntry->ProcessId);

								if (NT_SUCCESS(ntstatus)) {
									size_t length;
									ntstatus = RtlStringCbLengthA(string, _countof(string), &length);

									if (NT_SUCCESS(ntstatus))
										ntstatus = ZwWriteFile(file, NULL, NULL, NULL, &ioStatusBlock, string, (ULONG)length, NULL, NULL);
								}
							}
							processEntry = (PSYSTEM_PROCESSES)((BYTE*)processEntry + processEntry->NextEntryDelta);
						} while (processEntry->NextEntryDelta);
					}
					ExFreePoolWithTag(memory, POOL_TAG);
				}
			}
		}
		ZwClose(file);
	}

	return STATUS_SUCCESS;
}


NTSTATUS DispatchDeviceControl(PDEVICE_OBJECT deviceObject, PIRP irp) {
	UNREFERENCED_PARAMETER(deviceObject);

	PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(irp);
	ULONG controlCode = stack->Parameters.DeviceIoControl.IoControlCode;
	PVOID outputBuffer = irp->AssociatedIrp.SystemBuffer;
	//ULONG outputBufferLength = stack->Parameters.DeviceIoControl.OutputBufferLength;
	ULONG bytesReturned = 0;

	NTSTATUS status = STATUS_INVALID_DEVICE_REQUEST;

	switch (controlCode) {
	case codes::IOCTL_LIST_PROCESSES:
		status = ListProcesses();
		break;
	}

	irp->IoStatus.Status = status;
	irp->IoStatus.Information = bytesReturned;
	IoCompleteRequest(irp, IO_NO_INCREMENT);
	return status;
}

//Object passed between usermode and kernel
struct Request {
	ULONG RequestId; // Unique request ID
	ULONG DataLength; // Length of the data
	UCHAR Data[256]; // Buffer for data	
};

extern "C"
NTSTATUS DriverEntry(PDRIVER_OBJECT driverObject, PUNICODE_STRING registryPath) {
	DebugPrint("[+] Hello World! from kernel");

	UNICODE_STRING driverName = {};

	RtlInitUnicodeString(&driverName, L"\\Driver\\ExampleDriver");

	UNREFERENCED_PARAMETER(registryPath);

	UNICODE_STRING deviceName = {};
	RtlInitUnicodeString(&deviceName, L"\\Device\\ExampleDriver");
	PDEVICE_OBJECT deviceObject = nullptr;
	NTSTATUS status = IoCreateDevice(driverObject, 0, &deviceName, FILE_DEVICE_UNKNOWN, 0, FALSE, &deviceObject);

	if (status != STATUS_SUCCESS) {
		DebugPrint("[-] Failed to create driver device.\n");
		return status;
	}
	DebugPrint("[+] Success to create driver device.\n");

	UNICODE_STRING simbolicLink = {};
	RtlInitUnicodeString(&simbolicLink, L"\\??\\ExampleDriver");
	status = IoCreateSymbolicLink(&simbolicLink, &deviceName);

	if (status != STATUS_SUCCESS)
	{
		DebugPrint("[-] Failed to create simbolic link.\n");
		IoDeleteDevice(deviceObject);
		return status;
	}

	DebugPrint("[+] Success to create driver simbolic link.\n");

	driverObject->MajorFunction[IRP_MJ_CREATE] = DispatchCreateClose;
	driverObject->MajorFunction[IRP_MJ_CLOSE] = DispatchCreateClose;
	driverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DispatchDeviceControl;

	return status;
}